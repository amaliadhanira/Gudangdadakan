package com.miniproject.gudangdadakan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GudangdadakanApplicationTests {

	@Test
	void contextLoads() {
	}

}
